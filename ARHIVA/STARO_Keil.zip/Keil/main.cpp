#include "mbed.h"
#include <stdlib.h>     

#define pauza 0.01
#define prag 8
Serial pc(USBTX, USBRX); // tx, rx

// Na ovm piovima se nalaze senzori
AnalogIn   Senzor0(A0);
AnalogIn   Senzor1(A1);
AnalogIn   Senzor2(A2);
AnalogIn   Senzor3(A3);

// Promenljive
float senzori[4];
int i;
char prijem[5];


char recive(){
	char prijem[3]; //Dovoljno veliki bafer zbog sranja koja salje terminal
	int i;
	
	//Dodati rutinu da prima vise karaktera u jedan bafer
	c=pc.getc();
}

void send(){
						senzori[0]=Senzor0.read();
						wait(pauza);
						senzori[1]=Senzor1.read();
						wait(pauza);
						senzori[2]=Senzor2.read();
						wait(pauza);
						senzori[3]=Senzor3.read();
						wait(pauza);
						for(i=0;i<=3;i++){
							pc.printf("%f\n",senzori[i]);
						}
						pc.printf("END  END\n");
}
main() {
	
  pc.printf("Hello World !\n");
  while(1) { 
		send();

		}

  }

 

	
	
	

	
/*
while(1){
        
        if(Senzor1.read()<=0.5){
            pc.printf("1.000000\n");
            }
        else{
            pc.printf("0.000000\n");
            }    
        wait(pauza);
        
        if(Senzor2.read()<=0.5){
            pc.printf("1.000000\n");
            }
        else{
            pc.printf("0.000000\n");
            }    
        wait(pauza);
        
        if(Senzor3.read()<=0.5){
            pc.printf("1.000000\n");
            }
        else{
            pc.printf("0.000000\n");
            }    
        wait(pauza);
        if(Senzor4.read()<=0.5){
            pc.printf("1.000000\n");
            }
        else{
            pc.printf("0.000000\n");
            }    
        wait(pauza);        

        
        
        pc.printf("END  END\n");
        wait(pauza);
        }
}
*/
        
