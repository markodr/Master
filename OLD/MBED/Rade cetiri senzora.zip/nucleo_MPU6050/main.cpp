#include "mbed.h"
#include "MPU6050.h"
#define acc 16384
#define gyro 131
#define range_acc 0
#define range_gyr 0


MPU6050 mpu1(D14,D15); //C1SDA,C1SCL
MPU6050 mpu3(D14,D15); //C1SDA,C1SCL


MPU6050 mpu2(D5,D7); //C2SDA,C1SCL
MPU6050 mpu4(D5,D7); //C2SDA,C1SCL


Serial pc(USBTX, USBRX);

// 0 je ENABLE ZA 1 i 4 ACC

DigitalOut select1(D13); //ACC 1 select
DigitalOut select2(D12);  //ACC 2 select
DigitalOut select3(D11);  //ACC 3 select
DigitalOut select4(D8); //ACC 4 select








DigitalOut myled(LED1);


int main() {
    volatile float a1[3];
    volatile float a2[3];
    volatile float a3[3];
    volatile float a4[3];

// Ovo je za slucaj da nesto zakuca pa da vidim problem
    volatile float intezitet1=-1; 
    volatile float intezitet2=-1;
    volatile float intezitet3=-1;
    volatile float intezitet4=-1;

// Budzenje
    volatile float treshold=5;
    volatile float no_data=0;
    
    // Prvi Senzor
    mpu1.setAcceleroRange(range_acc);
    mpu1.setGyroRange(range_gyr);
    wait(0.5);
    
    // Drugi Senzor
    mpu2.setAcceleroRange(range_acc);
    mpu2.setGyroRange(range_gyr);
    wait(0.5);

    // Treci Senzor
    mpu3.setAcceleroRange(range_acc);
    mpu3.setGyroRange(range_gyr);
    wait(0.5);
       
    // Cetvrti Senzor
    mpu4.setAcceleroRange(range_acc);
    mpu4.setGyroRange(range_gyr);
    wait(0.5);
    
    
    while(1) {
           
// Prvi Senzor
        select1=0;
        a1[0] = (float)mpu1.getAcceleroRawX()/acc;
        a1[1] = (float)mpu1.getAcceleroRawY()/acc;
        a1[2] = (float)mpu1.getAcceleroRawZ()/acc;
        select1=1;
      
// Drugi Senzor
        select2=0;
        a2[0] = (float)mpu2.getAcceleroRawX()/acc;
        a2[1] = (float)mpu2.getAcceleroRawY()/acc;
        a2[2] = (float)mpu2.getAcceleroRawZ()/acc;
        select2=1;
        
// Treci Senzor se mesa sa prvim ??? Zameniti mesto senzorima
        select3=0;
        a3[0] = (float)mpu3.getAcceleroRawX()/acc;
        a3[1] = (float)mpu3.getAcceleroRawY()/acc;
        a3[2] = (float)mpu3.getAcceleroRawZ()/acc;
        select3=1; 

// Cetvrti Senzor
        select4=0;
        a4[0] = (float)mpu4.getAcceleroRawX()/acc;
        a4[1] = (float)mpu4.getAcceleroRawY()/acc;
        a4[2] = (float)mpu4.getAcceleroRawZ()/acc;
        select4=1;    



 
    // Prvi Senzor
        intezitet1=(a1[0]*a1[0]) + (a1[1]*a1[1]) + (a1[2]*a1[2]);
    // Drugi Senzor
        intezitet2=(a2[0]*a2[0]) + (a2[1]*a2[1]) + (a2[2]*a2[2]);        
    // Treci Senzor
        intezitet3=(a3[0]*a3[0]) + (a3[1]*a3[1]) + (a3[2]*a3[2]);         
    // Cetvrti Senzor
        intezitet4=(a4[0]*a4[0]) + (a4[1]*a4[1]) + (a4[2]*a4[2]);

        //pc.printf("Senzor 1 %f\n",intezitet1);
        //pc.printf("Senzor 2 %f\n",intezitet2);
        //pc.printf("Senzor 3 %f\n",intezitet3);
        //pc.printf("Senzor 4 %f\n",intezitet4);

       
        if(intezitet1>intezitet2 && intezitet1>intezitet3 && intezitet1>intezitet4 && intezitet1>treshold){
            intezitet1=10;
            intezitet2=no_data;
            intezitet3=no_data;
            intezitet4=no_data;            
            pc.printf("%f\n",intezitet1);
            pc.printf("%f\n",intezitet2);
            pc.printf("%f\n",intezitet3);
            pc.printf("%f\n",intezitet4);
            pc.printf("END  END\n");
            }
            
        if(intezitet2>intezitet1 && intezitet2>intezitet3 && intezitet2>intezitet4 && intezitet2>treshold){
            intezitet1=no_data;
            intezitet2=10;
            intezitet3=no_data;
            intezitet4=no_data;            
            pc.printf("%f\n",intezitet1);
            pc.printf("%f\n",intezitet2);
            pc.printf("%f\n",intezitet3);
            pc.printf("%f\n",intezitet4);
            pc.printf("END  END\n");
            }   
            
        if(intezitet3>intezitet1 && intezitet3>intezitet2 && intezitet3>intezitet4 && intezitet3>treshold){
            intezitet1=no_data;
            intezitet2=no_data;
            intezitet3=10;
            intezitet4=no_data;            
            pc.printf("%f\n",intezitet1);
            pc.printf("%f\n",intezitet2);
            pc.printf("%f\n",intezitet3);
            pc.printf("%f\n",intezitet4);
            pc.printf("END  END\n");
            }      
 
        if(intezitet4>intezitet1 && intezitet4>intezitet2 && intezitet4>intezitet3 && intezitet4>treshold){
            intezitet1=no_data;
            intezitet2=no_data;
            intezitet3=no_data;
            intezitet4=10;            
            pc.printf("%f\n",intezitet1);
            pc.printf("%f\n",intezitet2);
            pc.printf("%f\n",intezitet3);
            pc.printf("%f\n",intezitet4);
            pc.printf("END  END\n");
            }              

// Da probam da resim problem sa trecim senzorom 
            intezitet1=no_data;
            intezitet2=no_data;
            intezitet3=no_data;
            intezitet4=no_data;   



        // Mora jel LabView vrti podatke
        pc.printf("%f\n",no_data);        
        pc.printf("%f\n",no_data);
        pc.printf("%f\n",no_data);
        pc.printf("%f\n",no_data);
        pc.printf("END  END\n");
        
// END 




    }
}

        //g[0] = (float)mpu1.getGyroRawX()/gyro;
        //g[1] = (float)mpu1.getGyroRawY()/gyro;
        //g[2] = (float)mpu1.getGyroRawZ()/gyro;
        //pc.printf("ACC %f,%f,%f\n",a[0],a[1],a[2]);
        //pc.printf("GYR %f,%f,%f\n",g[0],g[1],g[2]);